import { Router } from 'express';

import {
  validate,
} from '../../common/validation/validate.js';

import {
  authController,
} from './auth.controller.js';

import {
  loginSchema,
  registerSchema,
  refreshSchema,
  logoutSchema,
} from './auth.schemas.js';

const router = Router();

router.post(
  '/register',
  validate(
    registerSchema,
    'body',
  ),
  authController.register,
);

router.post(
  '/login',
  validate(
    loginSchema,
    'body',
  ),
  authController.login,
);


router.post(
  '/refresh',
  validate(
    refreshSchema,
    'body',
  ),
  authController.refresh,
);

router.post(
  '/logout',
  validate(
    logoutSchema,
    'body',
  ),
  authController.logout,
);


export default router;