import type {
  Request,
  Response,
} from 'express';

import {
  toUserResponse,
} from '../users/user.mapper.js';

import {
  authService,
} from './auth.service.instance.js';

import type {
  LoginRequest,
  RegisterRequest,
  RefreshRequest,
  LogoutRequest,
} from './auth.schemas.js';


export const authController = {
  register: async (
    req: Request,
    res: Response,
  ): Promise<void> => {
    const input =
      req.body as RegisterRequest;

    const user =
      await authService.register(input);

    res.status(201).json({
      success: true,
      message:
        'Account created successfully',
      data: toUserResponse(user),
    });
  },

  login: async (
    req: Request,
    res: Response,
  ): Promise<void> => {
    const input =
      req.body as LoginRequest;

    const result =
      await authService.login(input);

    res.status(200).json({
      success: true,
      message: null,
      data: {
        accessToken:
        result.accessToken,

        refreshToken:
          result.refreshToken,

        tokenType:
          result.tokenType,

        expiresIn:
          result.expiresIn,

        user:
          toUserResponse(
            result.user,
          ),
      },
    });
  },

  refresh: async (
    req: Request,
    res: Response,
  ): Promise<void> => {
    const {
      refreshToken,
    } = req.body as RefreshRequest;

    const result =
      await authService.refresh(
        refreshToken,
      );

    res.status(200).json({
      success: true,
      message: null,
      data: result,
    });
  },

  logout: async (
    req: Request,
    res: Response,
  ): Promise<void> => {
    const {
      refreshToken,
    } = req.body as LogoutRequest;

    await authService.logout(
      refreshToken,
    );

    res.status(200).json({
      success: true,
      message:
        'Logged out successfully',
      data: null,
    });
  },

};